<link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
<footer>
  <div class="copyright">
    Copyright © 2020 shop show All Rights Reserved.
  </div>
</footer><?php /**PATH /Applications/MAMP/htdocs/shop_show/resources/views/footer.blade.php ENDPATH**/ ?>