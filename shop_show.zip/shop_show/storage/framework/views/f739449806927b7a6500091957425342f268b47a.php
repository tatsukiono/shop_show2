<link rel="stylesheet" href="<?php echo e(asset('css/shops/show.css')); ?>">
 
<body>

<?php $__env->startSection('content'); ?>
  <div class="section">
    <div class="content">
    <?php if(auth()->user()->id == $shop->user_id): ?>
    <div class="btn-box">
      <form action="/shops/<?php echo e($shop->id); ?>/edit" method="GET">
        <button type="submit" class="form-btn">編集</button>
      </form>
      
      <form action="/shops/delete/<?php echo e($shop->id); ?>" method="POST">
      <?php echo csrf_field(); ?>
        <button type="submit" class="form-btn">削除</button>
      </form>
    </div>
    <?php endif; ?>
    <img src="<?php echo e(asset('storage/image/'.$shop->image_url)); ?>" alt="" class="content-image">
    <div class="content-boxs">
      <div class="content-box">
        <div class="content-title">店舗名</div>
        <div class="content-value"><?php echo e($shop->name); ?></div>
      </div>
      <div class="content-box">
        <div class="content-title">値段帯</div>
        <div class="content-value"><?php echo e($shop->price); ?></div>
      </div>
      <div class="content-box">
        <div class="content-title">場所</div>
        <div class="content-value"><?php echo e($shop->location); ?></div>
      </div>
      <div class="content-title">感想</div>
      <div class="content-text"><?php echo e($shop->body); ?></div>
      <div class="card-body">
        <div class="row justify-content-center">
        <?php if(!$like): ?>
            <div class="col-md-3">
                <form action="<?php echo e($shop->id); ?>/favorites" method="POST">
                  <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($shop->id); ?>">
                    <input type="submit" value="いいね" class="fas btn btn-success">
                </form>
                <div class="like-count">いいね数：　<?php echo e($count); ?></div>
            </div>
        <?php else: ?>
            <div class="col-md-3">
                <form action="<?php echo e(route('unfavorites', $shop)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <input type="submit" value="いいね取り消す" class="fas btn btn-danger">
                </form>
            </div>
            <div class="like-count">いいね数：　<?php echo e($count); ?></div>
        <?php endif; ?>
        </div>
      </div>
      <a href="/shops" class="top">一覧ページへ</a>
    </div>
    </div>  
  </div>
<?php $__env->stopSection(); ?>
</body> 
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/shop_show/resources/views/shops/show.blade.php ENDPATH**/ ?>