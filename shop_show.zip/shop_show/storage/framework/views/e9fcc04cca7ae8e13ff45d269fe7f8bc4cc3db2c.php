<link rel="stylesheet" href="<?php echo e(asset('css/shops/form.css')); ?>">

<body>

<?php $__env->startSection('content'); ?>
  <div class="section">
    <div class="header-title">投稿</div>
    <form action="/shops" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
      <?php if($errors->has('name')): ?>
        <div class="error-message">
          <?php echo e($errors->first('name')); ?>

        </div>
      <?php endif; ?>
      <div class="form-title">店舗名</div>
      <input type="text" name="name" class="form" value="<?php echo e(old('name')); ?>">

      <div class="form-title">画像</div>
      <?php if($errors->has('image_url')): ?>
        <div class="error-message">
          <?php echo e($errors->first('image_url')); ?>

        </div>
      <?php endif; ?>
      <input type="file" name="image_url" class="form" value="<?php echo e(old('image_url')); ?>">
      <div class="note">※正しく投稿できなかった場合、再度画像の入力してください</div>

     
      <div class="form-title">場所</div>
      <?php if($errors->has('location')): ?>
        <div class="error-message">
          <?php echo e($errors->first('location')); ?>

        </div>
      <?php endif; ?>
      <input type="text" name="location" class="form" value="<?php echo e(old('location')); ?>">

      
      <div class="form-title">値段帯</div>
      <?php if($errors): ?>
        <div class="error-message">
          <?php echo e($errors->first('price')); ?>

        </div>
        <select name="price" class="form">
        <option value="<?php echo e(old('price')); ?>" selected><?php echo e(old('price')); ?></option>
          <?php if(old('price') == "〜1000円"): ?> {
          } <?php else: ?> { <option value="〜1000円">〜1000円</option> }
          <?php endif; ?>
          <?php if(old('price') == "1000~3000円"): ?> {
          } <?php else: ?> { <option value="1000~3000円">1000~3000円</option> }
          <?php endif; ?>
          <?php if(old('price') == "5000円〜"): ?> {
          } <?php else: ?> { <option value="5000円〜">5000円〜</option> }
          <?php endif; ?>
          <?php if(old('price') == "10000円〜"): ?> {
          } <?php else: ?> { <option value="10000円〜">10000円〜</option> }
          <?php endif; ?>
        </select>
      <?php else: ?>
        <select name="price" class="form">
          <option value=""></option>
          <option value="〜1000円">〜1000円</option>
          <option value="1000〜3000円">1000〜3000円</option>
          <option value="5000円〜">5000円〜</option>
          <option value="10000円〜">10000円〜</option>
        </select>
      <?php endif; ?>
      
      <div class="form-title">感想</div>
      <?php if($errors->has('body')): ?>
        <div class="error-message">
          <?php echo e($errors->first('body')); ?>

        </div>
      <?php endif; ?>
      <textarea name="body" class="form" cols="30" rows="5"><?php echo e(old('body')); ?></textarea>
      <button type="submit" class="submit">投稿</button>
    </form>
  </div>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/shop_show/resources/views/shops/form.blade.php ENDPATH**/ ?>