[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /Applications/MAMP/htdocs/shop_show/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>