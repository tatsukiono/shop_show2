<link href="css/shops/index.css" rel="stylesheet">

<body>

<?php $__env->startSection('content'); ?>
  <div class="section">
    <div class="header-title">投稿一覧</div>
    <div class="scroll-box">
      <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="/shops/<?php echo e($shop->id); ?>" class="a">
        <div class="content">
             <img src="<?php echo e(asset('storage/image/'.$shop->image_url)); ?>" alt="" class="content-image">
            <div class="content-price"><?php echo e($shop->price); ?></div>
            <div class="content-location"><?php echo e($shop->location); ?></div>
        </div>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/shop_show/resources/views/shops/index.blade.php ENDPATH**/ ?>