<link rel="stylesheet" href="<?php echo e(asset('css/shops/form-complete.css')); ?>">


<body>

<?php $__env->startSection('content'); ?>
<div class="section">
  <div class="header-title">削除が完了しました</div>
  <a href="/shops" class="top">一覧ページへ</a>
</div>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/shop_show/resources/views/shops/delete-complete.blade.php ENDPATH**/ ?>