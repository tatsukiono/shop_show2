<link rel="stylesheet" href="<?php echo e(asset('css/shops/form.css')); ?>">

<body>

<?php $__env->startSection('content'); ?>
  <div class="section">
    <div class="header-title">編集</div>
    <form action="/shops/update/<?php echo e($shop->price); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($shop->id); ?>">
      
      <div class="form-title">店舗名</div>
      <?php if($errors->has('name')): ?>
          <div class="error-message">
            <?php echo e($errors->first('name')); ?>

          </div>
      <?php endif; ?>
      <?php if(old('name')): ?>
      <input type="text" name="name" class="form" value="<?php echo e(old('name')); ?>">
      <?php elseif($errors->first('name') == '店舗名は必ず指定してください。'): ?>
      <input type="text" name="name" class="form" value="">
      <?php elseif($shop->name): ?>
        <input type="text" name="name" class="form" value="<?php echo e($shop->name); ?>">
      <?php endif; ?>

      
      <div class="form-title">画像</div>
      <?php if($errors->has('image_url')): ?>
        <div class="error-message">
          <?php echo e($errors->first('image_url')); ?>

        </div>
      <?php endif; ?>
      <input type="file" name="image_url" class="form" value="<?php echo e($shop->image_url); ?>">
      <div class="note">※編集前と同じ画像を投稿する場合も再度入力してください</div>
      

      <div class="form-title">場所</div>
      <?php if($errors->has('location')): ?>
        <div class="error-message">
          <?php echo e($errors->first('location')); ?>

        </div>
      <?php endif; ?>
      <?php if(old('location')): ?>
      <input type="text" name="location" class="form" value="<?php echo e(old('location')); ?>">
      <?php else: ?>
        <input type="text" name="location" class="form" value="<?php echo e($shop->location); ?>">
      <?php endif; ?>
      

      <div class="form-title">値段帯</div>
      <?php if(old('price')): ?>
        <select name="price" class="form">
          <option value="<?php echo e(old('price')); ?>" selected><?php echo e(old('price')); ?></option>
          <?php if($shop->price == "〜1000円"): ?> {
          } <?php else: ?> { <option value="〜1000円">〜1000円</option> }
          <?php endif; ?>
          <?php if($shop->price == "1000〜3000円"): ?> {
          } <?php else: ?> { <option value="1000〜3000円">1000〜3000円</option> }
          <?php endif; ?>
          <?php if($shop->price == "5000円〜"): ?> {
          } <?php else: ?> { <option value="5000円〜">5000円〜</option> }
          <?php endif; ?>
          <?php if($shop->price == "10000円〜"): ?> {
          } <?php else: ?> { <option value="10000円〜">10000円〜</option> }
          <?php endif; ?>
        </select>
      <?php else: ?>
        <select name="price" class="form">
        <option value="<?php echo e($shop->price); ?>" selected><?php echo e($shop->price); ?></option>
        <?php if($shop->price == "〜1000円"): ?> {
        } <?php else: ?> { <option value="〜1000円">〜1000円</option> }
        <?php endif; ?>
        <?php if($shop->price == "1000〜3000円"): ?> {
        } <?php else: ?> { <option value="1000〜3000円">1000〜3000円</option> }
        <?php endif; ?>
        <?php if($shop->price == "5000円〜"): ?> {
        } <?php else: ?> { <option value="5000円〜">5000円〜</option> }
        <?php endif; ?>
        <?php if($shop->price == "10000円〜"): ?> {
        } <?php else: ?> { <option value="10000円〜">10000円〜</option> }
        <?php endif; ?>
      </select>

      <?php endif; ?>
      

      <div class="form-title">感想</div>
      <?php if($errors->has('body')): ?>
        <div class="error-message">
          <?php echo e($errors->first('body')); ?>

        </div>
      <?php endif; ?>
      <?php if(old('body')): ?>
      <textarea name="body" class="form" cols="30" rows="5" value="<?php echo e(old('body')); ?>"><?php echo e(old('body')); ?></textarea>
      <?php elseif($errors->first('body') == '感想は必ず指定してください。'): ?>
      <textarea name="body" class="form" cols="30" rows="5" value=""></textarea>
      <?php elseif($shop->body): ?>
      <textarea name="body" class="form" cols="30" rows="5" value="<?php echo e($shop->body); ?>"><?php echo e($shop->body); ?></textarea>
      <?php endif; ?>
      
      <button type="submit" class="submit">投稿</button>
    </form>
  </div>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/shop_show/resources/views/shops/edit.blade.php ENDPATH**/ ?>