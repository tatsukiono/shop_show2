<link rel="stylesheet" href="<?php echo e(asset('css/shops/mypage.css')); ?>">


<body>

<?php $__env->startSection('content'); ?>
<div class="section">
    <div class="header-title"><?php echo e($name); ?>の投稿</div>
    <div class="scroll-box">
      <?php $__currentLoopData = $myshops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myshop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="/shops/<?php echo e($myshop->id); ?>" class="a">
        <div class="content">
             <img src="<?php echo e(asset('storage/image/'.$myshop->image_url)); ?>" alt="" class="content-image">
            <div class="content-price"><?php echo e($myshop->price); ?></div>
            <div class="content-location"><?php echo e($myshop->location); ?></div>
        </div>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <div class="section">
    <div class="header-title">いいねした投稿</div>
    <div class="scroll-box">
      <?php $__currentLoopData = $likeshops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $likeshop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <a href="/shops/<?php echo e($likeshop->id); ?>" class="a">
        <div class="content">
             <img src="<?php echo e(asset('storage/image/'.$likeshop->image_url)); ?>" alt="" class="content-image">
            <div class="content-price"><?php echo e($likeshop->price); ?></div>
            <div class="content-location"><?php echo e($likeshop->location); ?></div>
        </div>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/shop_show/resources/views/shops/mypage.blade.php ENDPATH**/ ?>