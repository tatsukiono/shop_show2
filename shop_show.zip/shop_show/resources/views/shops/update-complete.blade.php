<link rel="stylesheet" href="{{ asset('css/shops/form-complete.css') }}">


<body>
@extends('layout')
@section('content')
<div class="section">
  <div class="header-title">編集が完了しました</div>
  <a href="/shops" class="top">一覧ページへ</a>
</div>
@endsection
</body>
</html>