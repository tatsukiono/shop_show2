<link rel="stylesheet" href="{{ asset('css/footer.css') }}">
<footer>
  <div class="copyright">
    Copyright © 2020 shop show All Rights Reserved.
  </div>
</footer>